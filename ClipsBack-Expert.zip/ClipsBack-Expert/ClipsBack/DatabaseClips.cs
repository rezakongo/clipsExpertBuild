﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ClipsBack
{
    public class DatabaseClips
    {
        //string ID { get; set; };
        public ObservableCollection<DefTemplate> DefTemplates { get; set; }
        public ObservableCollection<DefFact> defFacts { get; set; }
        public ObservableCollection<Rule> Rules { get; set; }
        public DatabaseClips()
        {
            DefTemplates = new ObservableCollection<DefTemplate>();
            defFacts = new ObservableCollection<DefFact>();
            Rules = new ObservableCollection<Rule>();
        }
        public void AddDefTemplate(DefTemplate defTemplate)
        {
            DefTemplates.Add(defTemplate);
        }

        public void addFact(DefFact newFact)
        {
            defFacts.Add(newFact);
        }

        public void addRule(Rule newRule)
        {
            Rules.Add(newRule);
        }
    }
}
