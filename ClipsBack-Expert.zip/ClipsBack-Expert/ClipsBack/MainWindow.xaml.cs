﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.ComponentModel;
using CLIPSNET;



namespace ClipsBack
{
    class clipsFact
    {
        public string factName;
        public List<string> Attributes;
        public clipsFact(String Name,List<string> Attributes)
        {
            this.factName = Name;
            this.Attributes = Attributes;
        }
    }
    
    public partial class MainWindow : Window
    {
        List<clipsFact> Facts;
        List<string> newAttributes;
        private CLIPSNET.Environment clips;
        public MainWindow()
        {
            InitializeComponent();
            clips = new CLIPSNET.Environment();
            newAttributes = new List<string>();
            Facts = new List<clipsFact>();
        }
        private void button_Click_1(object sender, RoutedEventArgs e) //fact
        {
            newAttributes.Add(NewAttribute.Text);
            Attributes.Text = Attributes.Text + "\n" + NewAttribute.Text;
            NewAttribute.Text = "";
            //StreamWriter sw = new StreamWriter("init.txt");
            //sw.WriteLine("(+ 3 4)");
            //sw.Close();
            //clips.Build("(deftemplate person (slot name) (slot age))");
            //clips.Build(textBox.Text);
            //textBox.Text = "";
            //tabControl.SelectedIndex = 1;
            //clips.AssertString("(person (name \"Fred Jones\") (age 17))");
            //clips.AssertString("(person (name \"Sally Smith\") (age 23))");
            //clips.AssertString("(person (name \"Wally North\") (age 35))");
            //clips.AssertString("(person (name \"Jenny Wallis\") (age 11))");
            //clips.AssertString("(person (name \"khanoom sexie\") (age 24))");
            //Console.WriteLine("All people:");

            /*List<FactAddressValue> people = clips.FindAllFacts("person");

            foreach (FactAddressValue p in people)
            { Console.WriteLine(" " + p["name"]); }

            Console.WriteLine("All adults:");

            people = clips.FindAllFacts("?f", "person", "(>= ?f:age 18)");

            foreach (FactAddressValue p in people)
            { Console.WriteLine(" " + p["name"]); }*/

        }

        private void Create_Fact_Click(object sender, RoutedEventArgs e)
        {
            //string ClipsCommand= "(deftemplate "+FactsName.Text+" ";
            //foreach (string attribute in newAttributes)
            //{
            //    ClipsCommand += "(slot "+attribute+") ";
            //}
            //ClipsCommand += ")";

            //clips.Build(ClipsCommand);
            clips.Build("(deftemplate emergency (slot type))");
            clips.Build("(deftemplate response (slot action))");
            clips.Build("defrule fire-emergency (emergency (type fire)) => (assert (response (action active-spinkler)))");
            clips.Watch(CLIPSNET.Environment.RULES);
            clips.Reset();
            clips.Run();
        }

        private void assertObject_Click(object sender, RoutedEventArgs e)
        {
            clips.AssertString("(mmd (x "+xassert.Text+") (y "+yassert.Text+"))");
            xassert.Text = "";
            yassert.Text = "";
        }

        private void showAllFacts_Click(object sender, RoutedEventArgs e)
        {
            List<FactAddressValue> mmds = clips.FindAllFacts("mmd");
            foreach (var x in mmds)
            {
                allFactsShow.Text += x["x"].ToString() + "\n";
            }
        }
    }
}
