﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ClipsBack
{
    public class Rule
    {
        public string Name { get; set; }
        public string comment { get; set; }

        public string command="";

        public ObservableCollection<DefTemplate> Patterns { get; set; } = new ObservableCollection<DefTemplate>();
        public ObservableCollection<DefTemplate> Actions { get; set; } = new ObservableCollection<DefTemplate>();

        public Rule(ObservableCollection<DefTemplate> Patterns, ObservableCollection<DefTemplate> Actions)
        {
            Name = "Rule";
            
            foreach(var template in Patterns)
            {
                this.Patterns.Add(template);
            }
            foreach (var template in Actions)
            {
                this.Actions.Add(template);
            }

            command += "(defrule " + Name + " \"" + comment + "\" ";
            foreach(var template in this.Patterns)
            {
                command += "(" + template.Name + " ";
                foreach (var s in template.Slots)
                {
                    command += "(" + s.Name + " " + s.Value + ") ";
                }
                command += ")";
            }
            command += "=>";
            foreach (var template in this.Actions)
            {
                command += "( assert" + " ("+template.Name + " ";
                foreach(var s in template.Slots)
                {
                    command += "(" + s.Name + " " + s.Value + ")";
                }
                command += "))";
            }
            command += ")";
        }
    }
}
