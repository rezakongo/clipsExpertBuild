﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ClipsBack
{
    class function
    {
        public string name { get; set; }
        public ObservableCollection<string> vars { get; set; }
        public ObservableCollection<bool> types { get; set; }

        public string actions { get; set; }
        public string command { get; set; }
        public function(string name, ObservableCollection<string> vars, ObservableCollection<bool> types, string code)
        {
            this.name = name;
            this.vars = vars;
            this.actions = code;
            this.types = types;
            command = "(deffunction " + this.name + "(";
            for (int i = 0; i < vars.Count; i++)
            {
                if (types[i])
                {
                    command += " $?" + vars[i];
                }
                else
                {
                    command += " ?" + vars[i];
                }
            }
            command += " (" + this.command + "))";
        }
    }
}
