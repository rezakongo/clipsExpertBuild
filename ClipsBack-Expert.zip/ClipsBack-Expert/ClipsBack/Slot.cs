﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ClipsBack
{
    public class Slot
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public Slot(string name)
        {
            Name = name;
        }
        public Slot(string name, string value)
        {
            Name = name;
            Value = value;
        }
        public void AddValue(string value)
        {
            Value = value;
        }
    }
}
