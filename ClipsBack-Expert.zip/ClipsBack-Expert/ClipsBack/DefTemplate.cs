﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ClipsBack
{
    public class DefTemplate
    {
        public string Name { get; set; }
        public ObservableCollection<Slot> Slots { get; set; }
        public DefTemplate(string name)
        {
            this.Name = name;
            this.Slots = new ObservableCollection<Slot>();
        }
        public DefTemplate(string name, ObservableCollection<Slot> slots)
        {
            this.Name = name;
            this.Slots = new ObservableCollection<Slot>();
            foreach(var s in slots)
            {
                AddSlot(s.Name);
            }
        }
        public DefTemplate()
        {
            Name = "";
        }
        public void AddSlot(string slotName)
        {
            Slots.Add(new Slot(slotName));
        }
        public void AddSlot(Slot s)
        {
            Slots.Add(s);
        }
    }
}
