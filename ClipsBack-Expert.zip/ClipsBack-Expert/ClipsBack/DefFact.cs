﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using CLIPSNET;
namespace ClipsBack
{
    public class DefFact
    {
        public string Template { get; set; }
        Dictionary<Slot, string> slotValues=new Dictionary<Slot, string>();
        public string command = "";
        public string slots = "";
        public DefFact(string temp,Dictionary<Slot,string> slotvals)
        {
            Template = temp;
            foreach(var val in slotvals)
            {
                if (val.Value != "" && val.Value != null)
                {
                    slotValues.Add(val.Key, val.Value);
                }
            }

            
            slots = "(" + Template;
            foreach (var slot in slotValues)
            {
                slots += " ("+slot.Key.Name+" "+slot.Value+ ")";
            }
            slots += ")";
            command += "(assert "+slots+ ")";
        }
    }
}
