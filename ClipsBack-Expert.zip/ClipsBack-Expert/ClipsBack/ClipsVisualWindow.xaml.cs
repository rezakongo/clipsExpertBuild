﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using CLIPSNET;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using Microsoft.Win32;

namespace ClipsBack
{
    /// <summary>
    /// Interaction logic for ClipsVisualWindow.xaml
    /// </summary>
    public partial class ClipsVisualWindow
    {
        public string fileAddress { get; set; } = "";
        public static string DataBasePath = null;
        public SqlConnection CONNECTION = new SqlConnection(DataBasePath);
        public string User_ID = "alvin";
        private CLIPSNET.Environment clipsEnvironment = new CLIPSNET.Environment();
        public DatabaseClips databaseClips { get; set; } = new DatabaseClips();
        public string tempDefTemplateName { get; set; }
        public ObservableCollection<Slot> tempSlots { get; set; } = new ObservableCollection<Slot>();
        public ObservableCollection<DefTemplate> defTemplates { get; set; } = new ObservableCollection<DefTemplate>();
        public ObservableCollection<Slot> factDefTemplateSlots { get; set; } = new ObservableCollection<Slot>();
        public ObservableCollection<Slot> configuredFactSlots { get; set; } = new ObservableCollection<Slot>();
        public ObservableCollection<Slot> tempFactSlots { get; set; } = new ObservableCollection<Slot>();
        public string factDefTemplateName { get; set; }
        public string NewRuleCurrentDefTemplate { get; set; }
        public ObservableCollection<Slot> newRuleDeftemplateSlots { get; set; } = new ObservableCollection<Slot>();
        public ObservableCollection<Slot> newRuleCurrentDefTemplateSlots { get; set; } = new ObservableCollection<Slot>();
        public string newRuleCurrentTemplateType { get; set; }
        public ObservableCollection<DefTemplate> ifTemplates { get; set; } = new ObservableCollection<DefTemplate>();
        public ObservableCollection<DefTemplate> thenTemplates { get; set; } = new ObservableCollection<DefTemplate>();
        private FocusStack focusStack;
        private Dictionary<Focus, Agenda> agendaMap;

        public ObservableCollection<string> factsQuery;
        private MainWindow ide;
        string factsstr;
        public ObservableCollection<DefTemplate> executedFacts { get; set; } = new ObservableCollection<DefTemplate>();
        public ObservableCollection<Slot> tempExecutedFactSlots { get; set; } = new ObservableCollection<Slot>();

        public ClipsVisualWindow()
        {
            try
            {
                InitializeComponent();
                DataContext = this;
                focusStack = new FocusStack();
                agendaMap = new Dictionary<Focus, Agenda>();
                factsQuery = new ObservableCollection<string>();
                factsstr = "";
                StreamReader SR = new StreamReader("DataDetail.txt");
                SR.ReadLine();//skip the first line
                fileAddress = SR.ReadLine();
                datapath_load();

                string latestCommand = LoadDataBase();
                if (latestCommand != null)
                {
                    foreach (string command in latestCommand.Split('\n'))
                    {
                        if (command[1] == 'd' && command[2] == 'e' && command[3] == 'f' && command[4] == 't' && command[5] == 'e' && command[6] == 'm')
                        {
                            clipsEnvironment.Build(command);
                        }
                        else if (command[1] == 'd' && command[2] == 'e' && command[3] == 'f' && command[4] == 'r' && command[5] == 'u' && command[6] == 'l')
                        {
                            clipsEnvironment.LoadFromString(command);
                        }
                        else
                        {
                            clipsEnvironment.AssertString(command);
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }
        public void EmptyExecutedFact()
        {
            try
            {
                while (executedFacts.Count != 0)
                {
                    executedFacts.RemoveAt(executedFacts.Count - 1);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void TemplateTabButton_Checked(object sender, RoutedEventArgs e)
        {
            Tabs.SelectedItem = TemplateTab;
        }

        private void RuleTabButton_Checked(object sender, RoutedEventArgs e)
        {
            Tabs.SelectedItem = RuleTab;
        }

        private void FactTabButton_Checked(object sender, RoutedEventArgs e)
        {
            Tabs.SelectedItem = FactTab;
        }

        private void FunctionTabButton_Checked(object sender, RoutedEventArgs e)
        {
            //Tabs.SelectedItem = FuncTab;
        }

        private void ConfigureTemplateNameButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                tempDefTemplateName = TemplateNameTextBox.Text;
                removeAllElements(tempSlots);
                DataContext = this;
                SlotsListTitle.Text = tempDefTemplateName + "'s Slots";
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }
        private void ConfigureFunctSlotButton_Click(object sender, RoutedEventArgs e)
        {

        }
        
        private void ADDFunctSlotButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AddSlotNameButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (findSlotIndex(tempSlots, SlotNameTextBox.Text.Trim()) == -1)
                {
                    tempSlots.Add(new Slot(SlotNameTextBox.Text.Trim()));
                    SlotNameTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("Slot is already added!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void SlotRemoveButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                Slot slotToRemove = ((Border)sender).Tag as Slot;
                tempSlots.RemoveAt(findSlotIndex(tempSlots, slotToRemove.Name));
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }
        private int findSlotIndex(ObservableCollection<Slot> slots, string name)
        {
            try
            {
                int cnt = -1;
                foreach (var s in slots)
                {
                    cnt++;
                    if (s.Name == name)
                    {
                        return cnt;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            return -1;
        }
        private void removeAllElements(ObservableCollection<Slot> slots)
        {
            try
            {
                while (slots.Count != 0)
                {
                    slots.RemoveAt(slots.Count - 1);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void CreateTamplateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                databaseClips.AddDefTemplate(new DefTemplate(tempDefTemplateName, tempSlots));
                defTemplates.Add(new DefTemplate(tempDefTemplateName, tempSlots));
                string ClipsCommand = "(deftemplate " + tempDefTemplateName + " ";
                foreach (var s in tempSlots)
                {
                    ClipsCommand += "(slot " + s.Name + ") ";
                }
                ClipsCommand += ")";
                clipsEnvironment.Build(ClipsCommand);
                CheckDataBaseUser(ClipsCommand); //////////// to save or add to database
                MessageBox.Show("Added Successfully!");
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void factTemplatesCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //Slot slotToRemove = ((Border)sender).Tag as Slot;
                //tempSlots.RemoveAt(findSlotIndex(tempSlots, slotToRemove.Name));
                removeAllElements(factDefTemplateSlots);
                removeAllElements(configuredFactSlots);

                factDefTemplateName = (factTemplatesCombo.SelectedItem as DefTemplate).Name;
                foreach (var s in ((factTemplatesCombo.SelectedItem as DefTemplate).Slots))
                {
                    factDefTemplateSlots.Add(s);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void functTemplatesCombo_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void ConfigureFactSlotButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                configuredFactSlots.Add(new Slot((factSlotsNameCombo.SelectedItem as Slot).Name, factSlotValueTextBox.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }

        private void AddFactButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Dictionary<Slot, string> newFactSlots = new Dictionary<Slot, string>();
                for (int i = 0; i < configuredFactSlots.Count; i++)
                {
                    newFactSlots.Add(configuredFactSlots[i], configuredFactSlots[i].Value);
                }
                DefFact newFact = new DefFact(factDefTemplateName, newFactSlots);
                MessageBox.Show(factDefTemplateName);
                MessageBox.Show(newFact.command);

                CheckDataBaseUser(newFact.slots);

                clipsEnvironment.AssertString(newFact.slots);

                // configuredFactSlots include slots of the fact
                // factDefTemplateName is name of the defTamplate
                // use two above fellas to make a new facy
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }
        public void newFactQuery(ObservableCollection<string> factQuery)
        {
            try
            {
                while (factsQuery.Count > 0)
                {
                    factsQuery.RemoveAt(factsQuery.Count - 1);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }

        private void NewRuleTemplateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                NewRuleTemplateCombo.SelectedItem = null;
                IfRadio.IsChecked = false;
                ThenRadio.IsChecked = false;
                NewRuleSlotCombo.SelectedItem = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }

        }

        private void NewRuleTemplateCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (NewRuleTemplateCombo.SelectedItem != null)
                {
                    removeAllElements(newRuleCurrentDefTemplateSlots);
                    removeAllElements(newRuleDeftemplateSlots);
                    NewRuleTemplateNameTextBlock.Text = (NewRuleTemplateCombo.SelectedItem as DefTemplate).Name;
                    NewRuleCurrentDefTemplate = NewRuleTemplateNameTextBlock.Text;
                    foreach (var s in ((NewRuleTemplateCombo.SelectedItem as DefTemplate).Slots))
                    {
                        newRuleDeftemplateSlots.Add(s);
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }

        private void IfRadio_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                NewRuleTemplateNameTextBlock.Text += " (IF)";
                newRuleCurrentTemplateType = "if";
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void ThenRadio_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                NewRuleTemplateNameTextBlock.Text += " (THEN)";
                newRuleCurrentTemplateType = "then";
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void NewRuleAddSlotButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                newRuleCurrentDefTemplateSlots.Add(new Slot((NewRuleSlotCombo.SelectedItem as Slot).Name, NewRuleSlotValue.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }

        private void NewRuleFinalizeTemplateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DefTemplate d = new DefTemplate(NewRuleCurrentDefTemplate);
                foreach (var s in newRuleCurrentDefTemplateSlots)
                {
                    d.AddSlot(s);
                }
                if (newRuleCurrentTemplateType == "if")
                {
                    ifTemplates.Add(d);
                }
                else
                {
                    thenTemplates.Add(d);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void FinalizeRuleButton_Click(object sender, RoutedEventArgs e)
        {
            try 
            { 
                Rule newRule = new Rule(ifTemplates, thenTemplates);

                MessageBox.Show(newRule.command);
                CheckDataBaseUser(newRule.command);
                clipsEnvironment.Build(newRule.command);

            
                clipsEnvironment.LoadFromString(newRule.command);
                MessageBox.Show("Done!!!");
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }


            // ifTemplate includes deftemplates of if
            // thenTemplate includes deftemplates of then 
            // deftemplate is a class that has a name (name of deftemplate) and a collection of slots 
            // slot is a class that has a name and a value
        }

        private void closeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try 
            { 
                CONNECTION.Close();
                System.Windows.Application.Current.Shutdown();
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            //mainClipsWindow.Close();
        }

        private void closeButton_MouseEnter(object sender, MouseEventArgs e)
        {
            try
            {
                this.Cursor = Cursors.Hand;
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void closeButton_MouseLeave(object sender, MouseEventArgs e)
        {
            try
            {
                this.Cursor = Cursors.Arrow;
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }
        public void SaveToDataBase(string Command)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBasePath);
                con.Open();
                string command = "Insert into Table1 values('" + User_ID + "','" + Command.ToString().Trim() + "')";
                SqlCommand com = new SqlCommand(command, con);
                com.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Base Error");
            }
        }
        public void UpdateToDataBase(string Command)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBasePath);
                con.Open();
                string command = "select * from Table1 Where id = '" + User_ID + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(command, con);
                DataTable data1 = new DataTable();
                adapter.Fill(data1);
                string str = null;
                for (int i = 0; i < data1.Rows.Count; i++)
                {
                    str = data1.Rows[i][1].ToString();
                }
                StringBuilder sb = new StringBuilder();
                sb.Append(str);
                sb.Append("\n");
                sb.Append(Command);
                command = "UPDATE Table1 SET command = '" + sb.ToString().Trim() + "' Where id = '" + User_ID + "'";
                SqlCommand com = new SqlCommand(command, con);
                com.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Base Error");
            }
        }
        public void CheckDataBaseUser(string Command)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBasePath);

                string command = "select * from Table1 Where id = '" + User_ID + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(command, con);
                DataTable data1 = new DataTable();
                adapter.Fill(data1);
                string str = null;
                for (int i = 0; i < data1.Rows.Count; i++)
                {
                    str = data1.Rows[i][0].ToString();
                }
                if (str == null)
                {
                    SaveToDataBase(Command);
                }
                else
                {
                    UpdateToDataBase(Command);
                }
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Data Base Error");
            }
        }
        public string LoadDataBase()
        {
            SqlConnection con = new SqlConnection(DataBasePath);
            string str = null;
            try
            {
                con.Open();
                string command = "select * from Table1 Where id = '" + User_ID + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(command, con);
                DataTable data1 = new DataTable();
                adapter.Fill(data1);

                for (int i = 0; i < data1.Rows.Count; i++)
                {
                    str = data1.Rows[i][1].ToString();
                }
                con.Close();
                
            }
            catch(Exception)
            {

            }
            return str;
        }

        private void RunFactsTabButton_Checked(object sender, RoutedEventArgs e)
        {
            Tabs.SelectedItem = RunFacts;
        }

        private void RunFactsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                clipsEnvironment.Run();
                //factsstr = "";

                //newFactQuery(factsQuery);
                //foreach (var y in defTemplates)
                //{
                //    foreach (var x in clipsEnvironment.FindAllFacts(y.Name))
                //    {
                //        factsstr += x.ToString() + " : " + y.Name + "   Slots : [";
                //        foreach (var s in y.Slots)
                //        {
                //            factsstr += "   " + s.Name + " : " + x.GetSlotValue(s.Name);
                //        }
                //        factsstr += " ]";
                //        factsQuery.Add(factsstr);


                //    }
                //}
                //foreach(var q in factsQuery)
                //{
                //    Console.WriteLine(q);
                //}
                EmptyExecutedFact();
                foreach (var dt in defTemplates)
                {
                    foreach (var f in clipsEnvironment.FindAllFacts(dt.Name))
                    {
                        removeAllElements(tempExecutedFactSlots);
                        foreach (var s in dt.Slots)
                        {
                            string str = "" + f.GetSlotValue(s.Name);
                            tempExecutedFactSlots.Add(new Slot(s.Name, str));
                        }
                        executedFacts.Add(new DefTemplate(dt.Name));
                        foreach (var s in tempExecutedFactSlots)
                        {
                            executedFacts.ElementAt(executedFacts.Count - 1).AddSlot(s);
                        }
                    }
                }
                Console.WriteLine("Facts");
                foreach (var f in executedFacts)
                {
                    Console.WriteLine(f.Name);
                    foreach (var s in f.Slots)
                    {
                        Console.WriteLine(s.Name + " " + s.Value);
                    }
                }


                //MessageBox.Show("Done!!!");
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            
        }

        private void ImportDataButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CONNECTION.Close();
                OpenFileDialog fileDialog = new OpenFileDialog();
                if (fileDialog.ShowDialog() == true)
                {
                    fileAddress = fileDialog.FileName;
                    DataBaseFileName.Text = fileAddress;
                    StreamWriter SW = new StreamWriter("DataDetail.txt");
                    SW.WriteLine("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + fileAddress + ";Integrated Security=True;Connect Timeout=30");
                    SW.WriteLine(fileAddress);
                    SW.Close();
                }
                fileDialog.Reset();
                datapath_load();

                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                Application.Current.Shutdown();
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }
        private void datapath_load()
        {
            try
            {
            StreamReader SR = new StreamReader("DataDetail.txt");
            DataBasePath = SR.ReadLine();
            SR.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        private void ImportDataTabButton_Checked(object sender, RoutedEventArgs e)
        {
            Tabs.SelectedItem = Import;
        }
    }
}
